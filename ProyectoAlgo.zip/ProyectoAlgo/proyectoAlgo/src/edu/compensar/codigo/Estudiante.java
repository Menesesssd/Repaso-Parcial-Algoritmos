package edu.compensar.codigo;

import java.math.BigDecimal;

public class Estudiante {

    private final String codigo;
    private final String nombre;
    private final BigDecimal nota1;
    private final BigDecimal nota2;
    private final BigDecimal nota3;

    public Estudiante(String codigo, String nombre, BigDecimal nota1,
            BigDecimal nota2, BigDecimal nota3) {
        if (codigo == null || codigo.trim().isEmpty()
                || nombre == null || nombre.trim().isEmpty()) {
            throw new IllegalArgumentException("Ingrese el código y el nombre del estudiante.");
        }
        validarNota(nota1);
        validarNota(nota2);
        validarNota(nota3);

        this.codigo = codigo.trim();
        this.nombre = nombre.trim();
        this.nota1 = nota1;
        this.nota2 = nota2;
        this.nota3 = nota3;
    }

    private void validarNota(BigDecimal nota) {
        if (nota == null || nota.compareTo(BigDecimal.ZERO) < 0
                || nota.compareTo(new BigDecimal("5.0")) > 0) {
            throw new IllegalArgumentException("Las notas deben estar entre 0,0 y 5,0.");
        }
    }

    public BigDecimal calcularDefinitiva() {
        return nota1.multiply(new BigDecimal("0.30"))
                .add(nota2.multiply(new BigDecimal("0.30")))
                .add(nota3.multiply(new BigDecimal("0.40")));
    }

    public String getEstado() {
        if (calcularDefinitiva().compareTo(new BigDecimal("3.0")) >= 0) {
            return "Aprobado";
        } else {
            return "Reprobado";
        }
    }

    public String getCodigo() {
        return codigo;
    }

    public String getNombre() {
        return nombre;
    }

    public BigDecimal getNota1() {
        return nota1;
    }

    public BigDecimal getNota2() {
        return nota2;
    }

    public BigDecimal getNota3() {
        return nota3;
    }
}
