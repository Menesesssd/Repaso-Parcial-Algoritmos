package edu.compensar.codigo;

import javax.swing.SwingUtilities;

public class Calculadora {

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new VentanaCalculadora().setVisible(true));
    }
}
