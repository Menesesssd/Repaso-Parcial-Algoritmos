package edu.compensar.codigo;

import java.math.BigDecimal;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class VentanaCalculadora extends JFrame {

    private final DefaultTableModel modelo;

    public VentanaCalculadora() {
        initComponents();
        modelo = (DefaultTableModel) tabla.getModel();
        setLocationRelativeTo(null);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        formulario = new javax.swing.JPanel();
        etiquetaCodigo = new javax.swing.JLabel();
        campoCodigo = new javax.swing.JTextField();
        etiquetaNombre = new javax.swing.JLabel();
        campoNombre = new javax.swing.JTextField();
        etiquetaNota1 = new javax.swing.JLabel();
        campoNota1 = new javax.swing.JTextField();
        etiquetaNota2 = new javax.swing.JLabel();
        campoNota2 = new javax.swing.JTextField();
        etiquetaNota3 = new javax.swing.JLabel();
        campoNota3 = new javax.swing.JTextField();
        botonCalcular = new javax.swing.JButton();
        botonLimpiar = new javax.swing.JButton();
        desplazamiento = new javax.swing.JScrollPane();
        tabla = new javax.swing.JTable();
        etiquetaAyuda = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Calculadora de notas");
        setPreferredSize(new java.awt.Dimension(850, 500));
        getContentPane().setLayout(new java.awt.BorderLayout(10, 10));

        formulario.setBorder(javax.swing.BorderFactory.createTitledBorder("Datos del estudiante"));
        formulario.setLayout(new java.awt.GridLayout(6, 2, 10, 10));

        etiquetaCodigo.setText("Código:");
        formulario.add(etiquetaCodigo);
        formulario.add(campoCodigo);

        etiquetaNombre.setText("Nombre:");
        formulario.add(etiquetaNombre);
        formulario.add(campoNombre);

        etiquetaNota1.setText("Primera nota (30 %):");
        formulario.add(etiquetaNota1);
        formulario.add(campoNota1);

        etiquetaNota2.setText("Segunda nota (30 %):");
        formulario.add(etiquetaNota2);
        formulario.add(campoNota2);

        etiquetaNota3.setText("Tercera nota (40 %):");
        formulario.add(etiquetaNota3);
        formulario.add(campoNota3);

        botonCalcular.setText("Calcular y registrar");
        botonCalcular.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonCalcularActionPerformed(evt);
            }
        });
        formulario.add(botonCalcular);

        botonLimpiar.setText("Limpiar campos");
        botonLimpiar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonLimpiarActionPerformed(evt);
            }
        });
        formulario.add(botonLimpiar);

        getContentPane().add(formulario, java.awt.BorderLayout.NORTH);

        tabla.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Código", "Nombre", "Primera nota", "Segunda nota", "Tercera nota", "Definitiva", "Estado"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tabla.setRowHeight(25);
        desplazamiento.setViewportView(tabla);

        getContentPane().add(desplazamiento, java.awt.BorderLayout.CENTER);

        etiquetaAyuda.setText("Notas de 0,0 a 5,0. Se aprueba desde 3,0. Use coma o punto decimal.");
        getContentPane().add(etiquetaAyuda, java.awt.BorderLayout.SOUTH);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void botonCalcularActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonCalcularActionPerformed
        calcularYRegistrar();
    }//GEN-LAST:event_botonCalcularActionPerformed

    private void botonLimpiarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonLimpiarActionPerformed
        limpiarCampos();
    }//GEN-LAST:event_botonLimpiarActionPerformed

    private void calcularYRegistrar() {
        try {
            BigDecimal nota1 = leerNota(campoNota1.getText());
            BigDecimal nota2 = leerNota(campoNota2.getText());
            BigDecimal nota3 = leerNota(campoNota3.getText());

            Estudiante estudiante = new Estudiante(campoCodigo.getText(), campoNombre.getText(),
                    nota1, nota2, nota3);

            modelo.addRow(new Object[]{estudiante.getCodigo(), estudiante.getNombre(),
                estudiante.getNota1(), estudiante.getNota2(), estudiante.getNota3(),
                estudiante.calcularDefinitiva().stripTrailingZeros().toPlainString(),
                estudiante.getEstado()});
            limpiarCampos();
        } catch (IllegalArgumentException error) {
            JOptionPane.showMessageDialog(this, error.getMessage(),
                    "Datos inválidos", JOptionPane.WARNING_MESSAGE);
        }
    }

    private BigDecimal leerNota(String texto) {
        try {
            return new BigDecimal(texto.trim().replace(',', '.'));
        } catch (NumberFormatException error) {
            throw new IllegalArgumentException("Ingrese un número válido en las tres notas.");
        }
    }

    private void limpiarCampos() {
        campoCodigo.setText("");
        campoNombre.setText("");
        campoNota1.setText("");
        campoNota2.setText("");
        campoNota3.setText("");
        campoCodigo.requestFocusInWindow();
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton botonCalcular;
    private javax.swing.JButton botonLimpiar;
    private javax.swing.JTextField campoCodigo;
    private javax.swing.JTextField campoNombre;
    private javax.swing.JTextField campoNota1;
    private javax.swing.JTextField campoNota2;
    private javax.swing.JTextField campoNota3;
    private javax.swing.JScrollPane desplazamiento;
    private javax.swing.JLabel etiquetaAyuda;
    private javax.swing.JLabel etiquetaCodigo;
    private javax.swing.JLabel etiquetaNombre;
    private javax.swing.JLabel etiquetaNota1;
    private javax.swing.JLabel etiquetaNota2;
    private javax.swing.JLabel etiquetaNota3;
    private javax.swing.JPanel formulario;
    private javax.swing.JTable tabla;
    // End of variables declaration//GEN-END:variables
}
