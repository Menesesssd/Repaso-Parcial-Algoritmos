# Calculadora de notas

Taller de Algoritmos II. Aplicación sencilla en Java Swing, organizada en tres clases y sin librerías externas.

## Cómo ejecutarla

1. Abra esta carpeta como proyecto en NetBeans con JDK 26.
2. Ejecute el proyecto con F6.
3. Ingrese código, nombre y tres notas entre 0,0 y 5,0.
4. Pulse **Calcular y registrar** para agregar el estudiante a la tabla.

## Editar la interfaz con JFrame Form

En **Source Packages > edu.compensar.codigo**, abra `VentanaCalculadora.java` y seleccione la pestaña **Design**. Puede cambiar los textos y propiedades del formulario, los campos, los botones y la tabla desde el diseñador de NetBeans.

`VentanaCalculadora.form` guarda el diseño y debe conservarse junto al archivo Java. Los botones tienen sus eventos `actionPerformed`. Edite la lógica en los métodos que están fuera de `initComponents()`; NetBeans administra el bloque **Generated Code**.

Se aceptan decimales con coma o punto. Después de registrar un estudiante, los campos se limpian automáticamente. El botón **Limpiar campos** conserva los estudiantes de la tabla.

## Cálculo

`Definitiva = primera nota × 0,30 + segunda nota × 0,30 + tercera nota × 0,40`

- Definitiva igual o superior a 3,0: **Aprobado**.
- Definitiva inferior a 3,0: **Reprobado**.

Ejemplo: notas 4,0, 3,0 y 5,0 dan una definitiva de **4,1**.
Se usa `BigDecimal` para evitar errores de precisión al calcular con decimales.
Los datos se mantienen solo mientras la aplicación esté abierta.

## Código

Las tres clases están en `src/edu/compensar/codigo/`:

- `Calculadora.java`: contiene `main()` y abre la ventana.
- `Estudiante.java`: guarda código, nombre y notas; valida los datos y calcula la definitiva y el estado.
- `VentanaCalculadora.java`: organiza el formulario, los botones y la tabla. Convierte las entradas a números, crea un estudiante y muestra sus resultados. También limpia los campos.

La ventana usa la clase `Estudiante` para hacer el cálculo, por lo que los porcentajes y la regla de aprobación están separados de la interfaz.

## Entrega

Suba este proyecto a su repositorio y entregue el enlace, como solicita la consigna.
